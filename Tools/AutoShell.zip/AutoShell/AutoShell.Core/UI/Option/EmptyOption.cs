﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoShell.DataModel;

namespace AutoShell.UI.Option
{
    [DataSerializable]
    public class EmptyOption
    {
        public static readonly Guid OptionKey = new Guid("{7E44C4F2-D82E-4858-94A8-FEB96C4E3EE0}");
    }
}
