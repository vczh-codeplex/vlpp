/***********************************************************************
Vczh Library++ 3.0
Developer: �����(vczh)
GUI::Windows Platform

Interfaces:
***********************************************************************/

#ifndef VCZH_PRESENTATION_WINDOWSCORE_WINNATIVEWINDOW
#define VCZH_PRESENTATION_WINDOWSCORE_WINNATIVEWINDOW

#include "..\Core\GuiNativeWindow.h"
#include <windows.h>

namespace vl
{
	namespace presentation
	{
		namespace windows
		{

/***********************************************************************
Windows Platform Native Controller
***********************************************************************/

			class IWindowsForm : private Interface
			{
			public:
				virtual HWND				GetWindowHandle()=0;
			};

			extern INativeController*		CreateWindowsNativeController(HINSTANCE hInstance);
			extern IWindowsForm*			GetWindowsForm(INativeWindow* window);
			extern void						DestroyWindowsNativeController(INativeController* controller);
		}
	}
}

#endif