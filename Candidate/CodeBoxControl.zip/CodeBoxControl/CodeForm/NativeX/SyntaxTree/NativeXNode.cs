﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeBoxControl.CodeProvider;

namespace CodeForm.NativeX.SyntaxTree
{
    public abstract class NativeXNode : CodeNode
    {
    }
}
